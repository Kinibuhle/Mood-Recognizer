//30773954 Cindi M
#include <iostream>
#include <iomanip>
#include <string>
#include <algorithm> //used for calculation,data processing

using namespace std;
//declare and initialize global variables
const int MaxBooks=100;
const int MaxUsers=100;

//a struct to store details of the book
struct Book
{
    string title;
    string author;
    int PublicationYear;
};

//a class to make is easy to reuse the function
class Library
{
private:
    //declare all the variables
    Book books[MaxBooks];
    int numBooks;
    int totalBooksRemoved;

public:
    Library ():numBooks(0),totalBooksRemoved(0){}//initialize the member variable

 //a function to add book to the system
void addBook()
    {
        if(numBooks<MaxBooks)
        {
        //add books if only the maximum books record is not reached

            Book book;
            cout << "Enter book title: ";
            cin.ignore();
            getline(cin, book.title);
            cout << "Enter author of the book: ";
            getline(cin, book.author);
            cout << "Enter year published: ";
            cin >> book.PublicationYear;
            //add the number of books each time
            books[numBooks++]=book;

            cout << "Book added successfully." << endl;
            cout << "--------------------------------------------------" << endl;

        }
        else//give an output when the storage is full
            {
                cout<<"The library has reached its maximum book storage"<<endl;
                cout<< "--------------------------------------------------" << endl;
            }
    }
// a function to search the book by its title
void searchbyTitle(const string& title)
    {
        for (int i=0;i<numBooks;i++)
        {
            if (title == books[i].title)
            {
                cout << "Title: " << books[i].title << endl;
                cout << "Author: " << books[i].author << endl;
                cout << "Year Published: " << books[i].PublicationYear << endl;
                return; // Assuming there's only one book with the same title
            }
        }
        cout << "Book not found." << endl;//if the book is not found
        cout << "--------------------------------------------------" << endl;
    }
//a function to remove a book from the system
void removeBook(const string& title)
    {
        for(int i=0;i<numBooks;++i)
        {
            if(title==books[i].title)
            {
                //fill the gap of remaining elements
                for(int j=i;j<numBooks-1;++j)
                {
                    books[j]=books[j+1];
                }
                numBooks--;//decrement the number of books in the system
                totalBooksRemoved++;//increment the count of book(s) removed
                cout << "Book removed successfully." << endl;
                cout << "--------------------------------------------------" << endl;
            }
            else
        {
            cout << "Book not found." << endl;//if the book is not found
            cout << "--------------------------------------------------" << endl;
        }
        }

    }
//a function to give away books
void giveAwayBook(const string& title)
{
    int borrowedBooksCount=0;//a varible to store number of borrowd books
    int bookIndex=-1;
    for(int i=0;i<numBooks;i++)
    {
        if(title==books[i].title)
        {
            bookIndex=i;
            break;
        }
    }
    if (bookIndex == -1)
        {
            cout << "Book not found." << endl;
            cout << "----------------------------------------------------" << endl;
            return;//return if the index of the book is equal to -1
        }

        for (int i = 0; i < numBooks; i++)
        {
            if (title == books[i].title)
            {
                borrowedBooksCount++;//increment the borrowed books
            }
        }
        if (borrowedBooksCount > 5)//a condition of if the book has been borrowed more than 5 times
        {
            removeBook(title);

            cout << "Book has been given away successfully." << endl;
            cout << "--------------------------------------------------" << endl;
        }
        else
        {
            cout << "Book has not been borrowed more than 5 times, cannot be given away." << endl;
            cout << "---------------------------------------------------------" << endl;
        }
    }
// a function to show the summary of what was done
void summary()
    {
        cout << "--------------------------------------------------" << endl;
        cout << "KinoReads Library Summary. " << endl;
        cout << "--------------------------------------------------" << endl;
        cout << "Total books in the library: " << numBooks<< endl;
        cout << "Total books removed in the library: " <<totalBooksRemoved<<endl;

        cout << "--------------------------------------------------" << endl;}
};

int main()
{
    Library library;
    int Option;//declare variables
    string RemoveBook;
    do
    {
        //menu of the program
        cout << "--------------------------------------------------" << endl;
        cout << "Welcome to KinoReads Library Management System." << endl;
        cout << " " << endl;
        cout << "--------------------------------------------------" << endl;

        cout << "1. Add a book" << endl;
        cout << "2. Search by book" << endl;
        cout << "3. Remove book" << endl;
        cout << "4. Give away a book" << endl;
        cout << "5. Summary" << endl;
        cout << "6. Exit" << endl;
        cout << " " << endl;
        cout << "Choose an option: ";
        cin >> Option;

        switch (Option)
        {
        case 1:
            library.addBook();
            break;
        case 2:
            cout << "Enter the title to search for: ";
            cin.ignore();
            getline(cin, RemoveBook);
            library.searchbyTitle(RemoveBook);
            break;
        case 3:
            cout << "Enter a book you want to remove: ";
            cin.ignore();
            getline(cin, RemoveBook);
            library.removeBook(RemoveBook);
            cout << "Book removed: " <<RemoveBook<< endl;
            break;
        case 4:
            cout<<"Enter the title of the book to give away: ";
            cin.ignore();
            getline(cin,RemoveBook);
            library.giveAwayBook(RemoveBook);
            break;
        case 5:
            library.summary();
            break;
        case 6:
            cout << "Exiting..." << endl;
            cout << "--------------------------------------------------" << endl;
            return 0;
        default:
            cout << "Invalid option, please make a choice." << endl;
        }
    }
// a do-while check the condition at the end and stop only when the Option is no longer equal to 6
    while(Option!=6);
    return 0;
}

